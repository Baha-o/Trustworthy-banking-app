# Aegis customer banking dashboard

A full banking area for signed-in customers, styled in the same vault-chrome look as the landing and auth screens: deep ink surfaces, restrained gold accents, editorial serif headings, chrome hairlines.

## Screens

**Home / Accounts** — greeting with the customer's name, total balance across accounts, account cards showing type, masked number (•••• 4821) and balance, four quick actions (Transfer, Pay Bills, Deposit, Cards), and a recent transactions list with category and status badges.

**Transfers** — pick a source account, choose an internal account or a saved external recipient (or add a new one), enter an amount with live balance check, then a review-and-confirm step. On success, a printable-looking receipt with reference number, and a receipts list of past transfers.

**Transaction history** — full list with search box, and filters for date range, type (in/out), status, and category. Tapping a row opens a detail view with merchant, category, account, reference, and status timeline.

**Bill payments** — list of saved billers with logos/initials, pay a biller with amount and date, schedule a recurring payment (weekly/monthly), and add a new utility or service biller. Upcoming and past payments shown separately.

**Cards** — a digital card rendered in the vault style, tap to reveal full number/expiry/CVV (auto-hides), freeze/unfreeze toggle that visibly greys the card, monthly spending limit slider with usage bar, and PIN change plus contactless/online-payments toggles.

**Settings & profile** — name, phone, avatar initials, email (read-only), notification preferences (email, push, large-transaction alerts), and a prominent link into the existing two-factor/security page.

**Navigation** — bottom tab bar on phones (Home, Payments, Cards, Profile) with the safe-area inset respected; on desktop it becomes the existing top header nav. Transfers and history are reachable from Home and Payments.

## Data

New tables in the backend, all private to the signed-in customer (row-level security scoped to their user id):

- `accounts` — type (checking/savings/custody), masked + full number, currency, balance, status
- `transactions` — account, amount, direction, merchant/description, category, status, occurred_at, reference
- `recipients` — external payees: name, bank, masked account
- `billers` — name, category, account reference
- `bill_payments` — biller, amount, due/scheduled date, recurrence, status
- `cards` — account, brand, masked number, expiry, frozen flag, spending limit, contactless/online flags
- `notification_prefs` — per-user toggles

New customers get a realistic starter set automatically on first visit (three accounts, one card, a handful of billers and recipients, and ~40 transactions spread over recent months) so every screen has believable data to test with. Card numbers and PINs are demo values only — no real card data is stored.

## Technical notes

- Migration creates each table with GRANTs to `authenticated`, RLS enabled, and `auth.uid() = user_id` policies; `updated_at` triggers reuse the existing `set_updated_at()`.
- Seeding runs through an authenticated server function (`createServerFn` + `requireSupabaseAuth`) that is idempotent — it inserts only when the user has no accounts — called from the dashboard loader path, not from a public route.
- Transfers and bill payments execute in a `SECURITY DEFINER` SQL function so balance debit/credit and transaction rows commit atomically, with ownership and sufficient-funds checks inside.
- Routes added under `src/routes/_authenticated/`: `dashboard` (rewritten), `transfers`, `transactions`, `payments`, `cards`, `profile`. Reads go through TanStack Query with `useSuspenseQuery`; mutations invalidate the relevant keys.
- Shared pieces: `BottomNav`, `AccountCard`, `TransactionRow`, `StatusBadge`, `MoneyInput`, `ConfirmSheet`, currency/mask helpers in `src/lib/banking.ts`.
- Existing `_authenticated/route.tsx` header keeps sign-out and gains the new links; `security.tsx` stays as-is and is linked from profile.
