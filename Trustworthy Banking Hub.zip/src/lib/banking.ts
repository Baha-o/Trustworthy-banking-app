import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Account = Tables<"accounts">;
export type Transaction = Tables<"transactions">;
export type Recipient = Tables<"recipients">;
export type Biller = Tables<"billers">;
export type BillPayment = Tables<"bill_payments">;
export type Card = Tables<"cards">;
export type NotificationPrefs = Tables<"notification_prefs">;

export function money(value: number | string | null | undefined, currency = "EUR") {
  const n = typeof value === "string" ? Number(value) : (value ?? 0);
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(Number.isFinite(n) ? n : 0);
}

export function shortDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export function longDate(iso: string) {
  return new Date(iso).toLocaleString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function titleCase(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

let seedPromise: Promise<void> | null = null;

async function ensureSeed() {
  // Single-flight: parallel screens must not trigger two setups (which duplicated data).
  if (!seedPromise) {
    seedPromise = (async () => {
      try {
        await supabase.rpc("ensure_demo_data");
      } catch (err) {
        seedPromise = null;
        throw err;
      }
    })();
  }
  await seedPromise;
}

export const accountsQuery = queryOptions({
  queryKey: ["accounts"],
  queryFn: async (): Promise<Account[]> => {
    await ensureSeed();
    const { data, error } = await supabase
      .from("accounts")
      .select("*")
      .order("created_at", { ascending: true });
    if (error) throw error;
    return data ?? [];
  },
});

export const transactionsQuery = (limit?: number) =>
  queryOptions({
    queryKey: ["transactions", limit ?? "all"],
    queryFn: async (): Promise<Transaction[]> => {
      let q = supabase.from("transactions").select("*").order("occurred_at", { ascending: false });
      if (limit) q = q.limit(limit);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
  });

export const recipientsQuery = queryOptions({
  queryKey: ["recipients"],
  queryFn: async (): Promise<Recipient[]> => {
    const { data, error } = await supabase
      .from("recipients")
      .select("*")
      .order("name", { ascending: true });
    if (error) throw error;
    return data ?? [];
  },
});

export const billersQuery = queryOptions({
  queryKey: ["billers"],
  queryFn: async (): Promise<Biller[]> => {
    const { data, error } = await supabase
      .from("billers")
      .select("*")
      .order("name", { ascending: true });
    if (error) throw error;
    return data ?? [];
  },
});

export const billPaymentsQuery = queryOptions({
  queryKey: ["bill_payments"],
  queryFn: async (): Promise<BillPayment[]> => {
    const { data, error } = await supabase
      .from("bill_payments")
      .select("*")
      .order("due_date", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
});

export const cardsQuery = queryOptions({
  queryKey: ["cards"],
  queryFn: async (): Promise<Card[]> => {
    await ensureSeed();
    const { data, error } = await supabase
      .from("cards")
      .select("*")
      .order("created_at", { ascending: true });
    if (error) throw error;
    return data ?? [];
  },
});

export const profileQuery = queryOptions({
  queryKey: ["profile"],
  queryFn: async () => {
    const { data } = await supabase.from("profiles").select("*").maybeSingle();
    return data;
  },
});

export const notificationPrefsQuery = queryOptions({
  queryKey: ["notification_prefs"],
  queryFn: async (): Promise<NotificationPrefs | null> => {
    const { data } = await supabase.from("notification_prefs").select("*").maybeSingle();
    return data;
  },
});

export function errorMessage(error: unknown, fallback = "Something went wrong. Please try again.") {
  if (error && typeof error === "object" && "message" in error) {
    const message = String((error as { message: unknown }).message);
    if (message) return message;
  }
  return fallback;
}
