import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  AuthShell,
  fieldClass,
  ghostButtonClass,
  labelClass,
  primaryButtonClass,
} from "@/components/auth/AuthShell";

type Search = { mode?: "signin" | "signup"; redirect?: string };

export const Route = createFileRoute("/auth")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    mode: search['mode'] === "signup" ? "signup" : "signin",
    ...(typeof search['redirect'] === "string" && search['redirect'].startsWith("/")
      ? { redirect: search['redirect'] }
      : {}),
  }),
  head: () => ({
    meta: [
      { title: "Sign in — Trust Worthy Banking Hub" },
      {
        name: "description",
        content:
          "Access your Trust Worthy Banking Hub account securely with encrypted sign-in, verified email, and optional two-factor protection.",
      },
      { property: "og:title", content: "Sign in — Trust Worthy Banking Hub" },
      {
        property: "og:description",
        content: "Secure access to your Trust Worthy Banking Hub checking, savings, and custody accounts.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { mode, redirect } = Route.useSearch();
  const navigate = useNavigate();
  const isSignup = mode === "signup";

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [factorId, setFactorId] = useState<string | null>(null);
  const [challengeId, setChallengeId] = useState<string | null>(null);
  const [code, setCode] = useState("");

  const destination = redirect ?? "/dashboard";

  async function continueAfterPassword() {
    const { data, error: aalError } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
    if (aalError) throw aalError;
    if (data.nextLevel === "aal2" && data.nextLevel !== data.currentLevel) {
      const { data: factors, error: fErr } = await supabase.auth.mfa.listFactors();
      if (fErr) throw fErr;
      const totp = factors.totp[0];
      if (totp) {
        const { data: challenge, error: cErr } = await supabase.auth.mfa.challenge({
          factorId: totp.id,
        });
        if (cErr) throw cErr;
        setFactorId(totp.id);
        setChallengeId(challenge.id);
        return;
      }
    }
    await navigate({ to: destination, replace: true });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (isSignup) {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/verify-email`,
            data: { full_name: fullName },
          },
        });
        if (signUpError) throw signUpError;
        if (!data.session) {
          await navigate({
            to: "/verify-email",
            search: { email },
            replace: true,
          });
          return;
        }
        await navigate({ to: destination, replace: true });
        return;
      }

      const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
      if (signInError) throw signInError;
      await continueAfterPassword();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  async function onVerifyCode(e: React.FormEvent) {
    e.preventDefault();
    if (!factorId || !challengeId) return;
    setError(null);
    setBusy(true);
    try {
      const { error: verifyError } = await supabase.auth.mfa.verify({
        factorId,
        challengeId,
        code: code.trim(),
      });
      if (verifyError) throw verifyError;
      await navigate({ to: destination, replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "That code didn't work. Try again.");
    } finally {
      setBusy(false);
    }
  }

  if (challengeId) {
    return (
      <AuthShell
        eyebrow="Two-factor verification"
        title={
          <>
            One more <span className="chrome-text">seal</span> to open.
          </>
        }
        subtitle="Enter the 6-digit code from your authenticator app to finish signing in."
      >
        <form onSubmit={onVerifyCode} className="space-y-5">
          <div>
            <label className={labelClass} htmlFor="code">
              Verification code
            </label>
            <input
              id="code"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className={`${fieldClass} text-center font-mono text-lg tracking-[0.5em]`}
              placeholder="000000"
              required
            />
          </div>
          {error ? <ErrorNote message={error} /> : null}
          <button type="submit" className={primaryButtonClass} disabled={busy}>
            {busy ? "Verifying…" : "Verify and continue"}
          </button>
          <button
            type="button"
            className={ghostButtonClass}
            onClick={async () => {
              await supabase.auth.signOut();
              setChallengeId(null);
              setFactorId(null);
              setCode("");
            }}
          >
            Cancel
          </button>
        </form>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      eyebrow={isSignup ? "Open an account" : "Client access"}
      title={
        isSignup ? (
          <>
            Open your <span className="chrome-text">Trust Worthy</span> account.
          </>
        ) : (
          <>
            Welcome back to the <span className="chrome-text">vault</span>.
          </>
        )
      }
      subtitle={
        isSignup
          ? "A few details is all it takes. We'll email you a confirmation link before your first sign-in."
          : "Sign in with your email and password. Two-factor protection applies if you've enabled it."
      }
      footer={
        isSignup ? (
          <>
            Already a client?{" "}
            <Link
              to="/auth"
              search={{ mode: "signin" }}
              className="text-gold-2 underline-offset-4 hover:underline"
            >
              Sign in
            </Link>
          </>
        ) : (
          <>
            New to Trust Worthy Banking Hub?{" "}
            <Link
              to="/auth"
              search={{ mode: "signup" }}
              className="text-gold-2 underline-offset-4 hover:underline"
            >
              Open an account
            </Link>
          </>
        )
      }
    >
      <form onSubmit={onSubmit} className="space-y-5">
        {isSignup ? (
          <div>
            <label className={labelClass} htmlFor="fullName">
              Full name
            </label>
            <input
              id="fullName"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className={fieldClass}
              placeholder="Alexandra Vance"
              autoComplete="name"
              required
            />
          </div>
        ) : null}

        <div>
          <label className={labelClass} htmlFor="email">
            Email address
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className={fieldClass}
            placeholder="you@example.com"
            autoComplete="email"
            required
          />
        </div>

        <div>
          <div className="flex items-baseline justify-between">
            <label className={labelClass} htmlFor="password">
              Password
            </label>
            {!isSignup ? (
              <Link
                to="/forgot-password"
                className="mb-1.5 text-xs text-paper/50 transition-colors hover:text-gold-2"
              >
                Forgot?
              </Link>
            ) : null}
          </div>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={fieldClass}
            placeholder="••••••••••"
            autoComplete={isSignup ? "new-password" : "current-password"}
            minLength={8}
            required
          />
          {isSignup ? (
            <p className="mt-2 text-xs text-paper/45">
              At least 8 characters. We check new passwords against known breach lists.
            </p>
          ) : null}
        </div>

        {error ? <ErrorNote message={error} /> : null}

        <button type="submit" className={primaryButtonClass} disabled={busy}>
          {busy ? "Please wait…" : isSignup ? "Open account" : "Sign in"}
        </button>
      </form>
    </AuthShell>
  );
}

export function ErrorNote({ message }: { message: string }) {
  return (
    <p className="rounded-[10px] border border-destructive/40 bg-destructive/10 px-3.5 py-2.5 text-sm text-[#f7b4b4]">
      {message}
    </p>
  );
}
