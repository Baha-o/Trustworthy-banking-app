import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  AuthShell,
  fieldClass,
  labelClass,
  primaryButtonClass,
} from "@/components/auth/AuthShell";
import { ErrorNote } from "./auth";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Reset your password — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "Request a secure password reset link for your Trust Worthy Banking Hub account.",
      },
      { property: "og:title", content: "Reset your password — Trust Worthy Banking Hub" },
      {
        property: "og:description",
        content: "Request a secure password reset link for your Trust Worthy Banking Hub account.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ForgotPassword,
});

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setBusy(false);
    if (resetError) {
      setError(resetError.message);
      return;
    }
    setSent(true);
  }

  return (
    <AuthShell
      eyebrow="Account recovery"
      title={
        <>
          Reset your <span className="chrome-text">key</span>.
        </>
      }
      subtitle="Tell us the email on your account and we'll send a single-use link to set a new password."
      footer={
        <Link to="/auth" search={{ mode: "signin" }} className="text-gold-2 hover:underline">
          ← Back to sign in
        </Link>
      }
    >
      {sent ? (
        <div className="space-y-3">
          <p className="font-serif text-xl text-paper">Check your inbox</p>
          <p className="text-sm leading-relaxed text-paper/65">
            If an account exists for <span className="text-gold-2">{email}</span>, a reset link is
            on its way. The link expires shortly for your security.
          </p>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="space-y-5">
          <div>
            <label className={labelClass} htmlFor="email">
              Email address
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={fieldClass}
              placeholder="you@example.com"
              autoComplete="email"
              required
            />
          </div>
          {error ? <ErrorNote message={error} /> : null}
          <button type="submit" className={primaryButtonClass} disabled={busy}>
            {busy ? "Sending…" : "Send reset link"}
          </button>
        </form>
      )}
    </AuthShell>
  );
}
