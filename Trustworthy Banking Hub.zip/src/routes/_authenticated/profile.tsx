import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  accountsQuery,
  errorMessage,
  initials,
  money,
  notificationPrefsQuery,
  profileQuery,
} from "@/lib/banking";
import {
  Note,
  Panel,
  PageHeader,
  fieldClass,
  labelClass,
  primaryButtonClass,
} from "@/components/banking/ui";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Profile & settings — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "Update your contact details, notification preferences, and security settings.",
      },
      { property: "og:title", content: "Profile & settings — Trust Worthy Banking Hub" },
      { property: "og:description", content: "Manage your Trust Worthy Banking Hub profile and preferences." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Profile,
});

function Profile() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const profile = useQuery(profileQuery);
  const prefs = useQuery(notificationPrefsQuery);
  const accounts = useQuery(accountsQuery);

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (profile.data) {
      setFullName(profile.data.full_name ?? "");
      setPhone(profile.data.phone ?? "");
    }
  }, [profile.data]);

  const saveProfile = useMutation({
    mutationFn: async () => {
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ full_name: fullName, phone })
        .eq("id", user!.id);
      if (updateError) throw updateError;
    },
    onSuccess: () => {
      setNotice("Your details were saved.");
      void qc.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (err) => setError(errorMessage(err)),
  });

  const savePrefs = useMutation({
    mutationFn: async (patch: Record<string, boolean>) => {
      const { error: upsertError } = await supabase
        .from("notification_prefs")
        .upsert({ user_id: user!.id, ...patch });
      if (upsertError) throw upsertError;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["notification_prefs"] }),
    onError: (err) => setError(errorMessage(err)),
  });

  const toggles = [
    ["Email alerts", "email_alerts", prefs.data?.email_alerts ?? true],
    ["Push alerts", "push_alerts", prefs.data?.push_alerts ?? false],
    [
      "Large transaction alerts",
      "large_transaction_alerts",
      prefs.data?.large_transaction_alerts ?? true,
    ],
  ] as const;

  const total = (accounts.data ?? []).reduce((sum, a) => sum + Number(a.balance), 0);

  return (
    <main className="mx-auto max-w-6xl px-6 py-10 lg:px-8">
      <PageHeader eyebrow="Settings" title="Profile" subtitle="Your details and how we reach you." />

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1fr]">
        <Panel>
          <div className="flex items-center gap-4">
            <span className="grid size-14 place-items-center rounded-full bg-ink font-serif text-lg text-paper">
              {initials(fullName || user?.email || "A")}
            </span>
            <div className="min-w-0">
              <p className="truncate font-serif text-xl font-semibold text-ink">
                {fullName || "Trust Worthy Banking Hub customer"}
              </p>
              <p className="truncate text-sm text-steel">{user?.email}</p>
            </div>
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <label className={labelClass} htmlFor="fullName">
                Full name
              </label>
              <input
                id="fullName"
                className={fieldClass}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
              />
            </div>
            <div>
              <label className={labelClass} htmlFor="phone">
                Phone
              </label>
              <input
                id="phone"
                className={fieldClass}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 555 0100"
              />
            </div>
            <div>
              <label className={labelClass} htmlFor="email">
                Email
              </label>
              <input id="email" className={`${fieldClass} bg-paper-2`} value={user?.email ?? ""} readOnly />
            </div>
            {error ? <Note tone="error">{error}</Note> : null}
            {notice ? <Note tone="success">{notice}</Note> : null}
            <button
              type="button"
              className={primaryButtonClass}
              disabled={saveProfile.isPending}
              onClick={() => {
                setError(null);
                setNotice(null);
                saveProfile.mutate();
              }}
            >
              {saveProfile.isPending ? "Saving…" : "Save changes"}
            </button>
          </div>
        </Panel>

        <div className="space-y-6">
          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Accounts</h2>
            <ul className="mt-3 divide-y divide-ink/5 text-sm">
              {(accounts.data ?? []).map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-4 py-3">
                  <span>
                    <span className="block text-ink">{a.name}</span>
                    <span className="font-mono text-xs text-steel">{a.number_masked}</span>
                  </span>
                  <span className="font-mono text-ink">{money(a.balance, a.currency)}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-sm text-steel">Total {money(total)}</p>
          </Panel>

          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Notifications</h2>
            <div className="mt-4 space-y-4">
              {toggles.map(([label, key, value]) => (
                <div key={key} className="flex items-center justify-between gap-4">
                  <span className="text-sm text-ink">{label}</span>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={value}
                    aria-label={label}
                    onClick={() => savePrefs.mutate({ [key]: !value })}
                    className={`h-6 w-11 rounded-full transition-colors ${value ? "bg-ink" : "bg-ink/20"}`}
                  >
                    <span
                      className={`block size-5 rounded-full bg-paper transition-transform ${
                        value ? "translate-x-5" : "translate-x-0.5"
                      }`}
                    />
                  </button>
                </div>
              ))}
            </div>
          </Panel>

          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Security</h2>
            <p className="mt-2 text-sm text-steel">
              Two-factor authentication, password, and sign-in protection.
            </p>
            <Link to="/security" className={`${primaryButtonClass} mt-4 inline-block`}>
              Open security settings
            </Link>
          </Panel>
        </div>
      </div>
    </main>
  );
}
