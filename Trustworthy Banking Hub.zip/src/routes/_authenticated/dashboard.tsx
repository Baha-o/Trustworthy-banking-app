import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  accountsQuery,
  cardsQuery,
  money,
  profileQuery,
  transactionsQuery,
  titleCase,
} from "@/lib/banking";
import { useAuth } from "@/hooks/useAuth";
import { EmptyState, Loading, Panel } from "@/components/banking/ui";
import { TransactionRow } from "@/components/banking/TransactionRow";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Your accounts — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "A private overview of your Trust Worthy Banking Hub checking, savings, and custody accounts.",
      },
      { property: "og:title", content: "Your accounts — Trust Worthy Banking Hub" },
      { property: "og:description", content: "A private overview of your Trust Worthy Banking Hub accounts." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

const quickActions = [
  { to: "/transfers", label: "Transfer", glyph: "⇄" },
  { to: "/payments", label: "Pay bills", glyph: "◫" },
  { to: "/transfers", label: "Deposit", glyph: "↓" },
  { to: "/cards", label: "Cards", glyph: "▢" },
] as const;

function Dashboard() {
  const { user } = useAuth();
  const profile = useQuery(profileQuery);
  const accounts = useQuery(accountsQuery);
  const transactions = useQuery(transactionsQuery(6));
  const cards = useQuery(cardsQuery);

  const greeting =
    profile.data?.full_name?.split(" ")[0] ?? user?.email?.split("@")[0] ?? "there";
  const total = (accounts.data ?? []).reduce((sum, a) => sum + Number(a.balance), 0);
  const frozen = cards.data?.some((c) => c.frozen);

  return (
    <main className="mx-auto max-w-6xl px-6 py-10 lg:px-8">
      <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-steel">Account home</p>
      <h1 className="mt-2 font-serif text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
        Good to see you, {greeting}.
      </h1>

      <section className="vault-face mt-8 overflow-hidden rounded-2xl p-7 text-paper shadow-sm">
        <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-paper/50">
          Total balance
        </p>
        <p className="mt-2 font-serif text-4xl font-semibold sm:text-5xl">
          {accounts.isLoading ? "—" : money(total)}
        </p>
        <div className="chrome-line mt-6" />
        <p className="mt-4 text-sm text-paper/60">
          Across {accounts.data?.length ?? 0} accounts
          {frozen ? " · one card is frozen" : ""}
        </p>
      </section>

      <section className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {quickActions.map((action) => (
          <Link
            key={action.label}
            to={action.to}
            className="lift rounded-2xl border border-ink/10 bg-white p-4 text-center shadow-sm"
          >
            <span aria-hidden className="block text-xl text-gold-3">
              {action.glyph}
            </span>
            <span className="mt-2 block text-sm font-medium text-ink">{action.label}</span>
          </Link>
        ))}
      </section>

      <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {accounts.isLoading
          ? null
          : (accounts.data ?? []).map((account) => (
              <div
                key={account.id}
                className="lift rounded-2xl border border-ink/10 bg-white p-6 shadow-sm"
              >
                <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-steel">
                  {titleCase(account.kind)}
                </p>
                <p className="mt-1 text-sm font-medium text-ink">{account.name}</p>
                <p className="mt-4 font-serif text-3xl font-semibold text-ink">
                  {money(account.balance, account.currency)}
                </p>
                <p className="mt-1 font-mono text-xs text-steel">{account.number_masked}</p>
              </div>
            ))}
      </section>

      <Panel className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg font-semibold text-ink">Recent activity</h2>
          <Link to="/transactions" className="text-sm text-gold-3 hover:underline">
            View all
          </Link>
        </div>
        <div className="mt-2 divide-y divide-ink/5">
          {transactions.isLoading ? (
            <Loading />
          ) : (transactions.data ?? []).length === 0 ? (
            <EmptyState title="No transactions yet" />
          ) : (
            (transactions.data ?? []).map((tx) => <TransactionRow key={tx.id} tx={tx} />)
          )}
        </div>
      </Panel>
    </main>
  );
}
