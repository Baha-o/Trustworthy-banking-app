import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  accountsQuery,
  errorMessage,
  longDate,
  money,
  recipientsQuery,
  transactionsQuery,
  type Transaction,
} from "@/lib/banking";
import {
  Note,
  Panel,
  PageHeader,
  fieldClass,
  ghostButtonClass,
  labelClass,
  primaryButtonClass,
} from "@/components/banking/ui";

export const Route = createFileRoute("/_authenticated/transfers")({
  head: () => ({
    meta: [
      { title: "Transfer money — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "Move money between your Trust Worthy Banking Hub accounts or send it to a saved recipient.",
      },
      { property: "og:title", content: "Transfer money — Trust Worthy Banking Hub" },
      { property: "og:description", content: "Move money between accounts or to a recipient." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Transfers,
});

function Transfers() {
  const qc = useQueryClient();
  const accounts = useQuery(accountsQuery);
  const recipients = useQuery(recipientsQuery);
  const recent = useQuery(transactionsQuery(50));

  const [from, setFrom] = useState("");
  const [destination, setDestination] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [step, setStep] = useState<"form" | "review">("form");
  const [receipt, setReceipt] = useState<Transaction | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [newName, setNewName] = useState("");
  const [newBank, setNewBank] = useState("");
  const [newAccount, setNewAccount] = useState("");

  const list = accounts.data ?? [];
  const fromAccount = list.find((a) => a.id === from) ?? list[0];
  const [kind, id] = destination.split(":");
  const toAccount = kind === "account" ? list.find((a) => a.id === id) : undefined;
  const toRecipient = kind === "recipient" ? recipients.data?.find((r) => r.id === id) : undefined;
  const value = Number(amount);
  const destinationLabel = toAccount?.name ?? toRecipient?.name ?? "";

  const transfer = useMutation({
    mutationFn: async () => {
      const { data, error: rpcError } = await supabase.rpc("make_transfer", {
        _from_account: fromAccount!.id,
        _amount: value,
        ...(toAccount ? { _to_account: toAccount.id } : {}),
        ...(toRecipient ? { _recipient_id: toRecipient.id } : {}),
        ...(note ? { _note: note } : {}),
      });
      if (rpcError) throw rpcError;
      return data as unknown as Transaction;
    },
    onSuccess: (tx) => {
      setReceipt(tx);
      setStep("form");
      setAmount("");
      setNote("");
      void qc.invalidateQueries({ queryKey: ["accounts"] });
      void qc.invalidateQueries({ queryKey: ["transactions"] });
    },
    onError: (err) => setError(errorMessage(err)),
  });

  const addRecipient = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      const { error: insertError } = await supabase.from("recipients").insert({
        user_id: userData.user!.id,
        name: newName,
        bank_name: newBank || null,
        account_masked: newAccount,
      });
      if (insertError) throw insertError;
    },
    onSuccess: () => {
      setNewName("");
      setNewBank("");
      setNewAccount("");
      void qc.invalidateQueries({ queryKey: ["recipients"] });
    },
    onError: (err) => setError(errorMessage(err)),
  });

  function review() {
    setError(null);
    setReceipt(null);
    if (!fromAccount) return setError("Choose an account to send from.");
    if (!destination) return setError("Choose where the money should go.");
    if (!value || value <= 0) return setError("Enter an amount greater than zero.");
    if (value > Number(fromAccount.balance))
      return setError(`That is more than the ${money(fromAccount.balance)} available.`);
    setStep("review");
  }

  const transferHistory = (recent.data ?? []).filter(
    (tx) => tx.category === "transfer" && tx.direction === "out",
  );

  return (
    <main className="mx-auto max-w-6xl px-6 py-10 lg:px-8">
      <PageHeader
        eyebrow="Move money"
        title="Transfers"
        subtitle="Between your own accounts, or out to someone you have saved."
      />

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <Panel>
          {step === "form" ? (
            <div className="space-y-5">
              <div>
                <label className={labelClass} htmlFor="from">
                  From
                </label>
                <select
                  id="from"
                  className={fieldClass}
                  value={fromAccount?.id ?? ""}
                  onChange={(e) => setFrom(e.target.value)}
                >
                  {list.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name} — {money(a.balance, a.currency)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass} htmlFor="to">
                  To
                </label>
                <select
                  id="to"
                  className={fieldClass}
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                >
                  <option value="">Select a destination</option>
                  <optgroup label="My accounts">
                    {list
                      .filter((a) => a.id !== fromAccount?.id)
                      .map((a) => (
                        <option key={a.id} value={`account:${a.id}`}>
                          {a.name} {a.number_masked}
                        </option>
                      ))}
                  </optgroup>
                  <optgroup label="Recipients">
                    {(recipients.data ?? []).map((r) => (
                      <option key={r.id} value={`recipient:${r.id}`}>
                        {r.name} {r.account_masked}
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>

              <div>
                <label className={labelClass} htmlFor="amount">
                  Amount
                </label>
                <div className="flex items-center gap-2">
                  <span className="font-serif text-2xl text-steel">$</span>
                  <input
                    id="amount"
                    inputMode="decimal"
                    placeholder="0.00"
                    className={`${fieldClass} font-mono text-lg`}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                  />
                </div>
                {fromAccount ? (
                  <p className="mt-1.5 text-xs text-steel">
                    {money(fromAccount.balance, fromAccount.currency)} available
                  </p>
                ) : null}
              </div>

              <div>
                <label className={labelClass} htmlFor="note">
                  Note (optional)
                </label>
                <input
                  id="note"
                  className={fieldClass}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Rent, invoice 204…"
                />
              </div>

              {error ? <Note tone="error">{error}</Note> : null}

              <button type="button" onClick={review} className={primaryButtonClass}>
                Review transfer
              </button>
            </div>
          ) : (
            <div className="space-y-5">
              <h2 className="font-serif text-xl font-semibold text-ink">Confirm this transfer</h2>
              <dl className="divide-y divide-ink/5 rounded-xl bg-paper-2/60 px-4">
                {[
                  ["From", `${fromAccount?.name} ${fromAccount?.number_masked}`],
                  ["To", destinationLabel],
                  ["Amount", money(value)],
                  ["Note", note || "—"],
                ].map(([term, detail]) => (
                  <div key={term} className="flex justify-between gap-6 py-3 text-sm">
                    <dt className="text-steel">{term}</dt>
                    <dd className="text-right font-medium text-ink">{detail}</dd>
                  </div>
                ))}
              </dl>
              {error ? <Note tone="error">{error}</Note> : null}
              <div className="flex gap-3">
                <button
                  type="button"
                  className={primaryButtonClass}
                  disabled={transfer.isPending}
                  onClick={() => transfer.mutate()}
                >
                  {transfer.isPending ? "Sending…" : "Send money"}
                </button>
                <button
                  type="button"
                  className={ghostButtonClass}
                  onClick={() => setStep("form")}
                  disabled={transfer.isPending}
                >
                  Back
                </button>
              </div>
            </div>
          )}

          {receipt ? (
            <div className="mt-6 rounded-2xl border border-gold/40 bg-paper-2/60 p-5">
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-gold-3">
                Receipt
              </p>
              <p className="mt-2 font-serif text-2xl font-semibold text-ink">
                {money(receipt.amount)} sent
              </p>
              <p className="mt-1 text-sm text-steel">{receipt.description}</p>
              <div className="chrome-line my-4" />
              <p className="font-mono text-xs text-steel">
                Reference {receipt.reference} · {longDate(receipt.occurred_at)}
              </p>
            </div>
          ) : null}
        </Panel>

        <div className="space-y-6">
          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Add a recipient</h2>
            <div className="mt-4 space-y-3">
              <input
                className={fieldClass}
                placeholder="Full name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
              />
              <input
                className={fieldClass}
                placeholder="Bank name"
                value={newBank}
                onChange={(e) => setNewBank(e.target.value)}
              />
              <input
                className={fieldClass}
                placeholder="Account number"
                value={newAccount}
                onChange={(e) => setNewAccount(e.target.value)}
              />
              <button
                type="button"
                className={ghostButtonClass}
                disabled={!newName || !newAccount || addRecipient.isPending}
                onClick={() => addRecipient.mutate()}
              >
                {addRecipient.isPending ? "Saving…" : "Save recipient"}
              </button>
            </div>
          </Panel>

          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Transfer receipts</h2>
            <ul className="mt-3 divide-y divide-ink/5 text-sm">
              {transferHistory.length === 0 ? (
                <li className="py-4 text-steel">No transfers yet.</li>
              ) : (
                transferHistory.slice(0, 8).map((tx) => (
                  <li key={tx.id} className="flex items-center justify-between gap-4 py-3">
                    <span className="min-w-0">
                      <span className="block truncate text-ink">{tx.description}</span>
                      <span className="font-mono text-xs text-steel">{tx.reference}</span>
                    </span>
                    <span className="font-mono text-ink">{money(tx.amount)}</span>
                  </li>
                ))
              )}
            </ul>
          </Panel>
        </div>
      </div>
    </main>
  );
}
