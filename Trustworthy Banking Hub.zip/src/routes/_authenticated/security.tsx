import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ErrorNote } from "../auth";

export const Route = createFileRoute("/_authenticated/security")({
  head: () => ({
    meta: [
      { title: "Security settings — Trust Worthy Banking Hub" },
      {
        name: "description",
        content:
          "Manage two-factor authentication and your password for your Trust Worthy Banking Hub account.",
      },
      { property: "og:title", content: "Security settings — Trust Worthy Banking Hub" },
      {
        property: "og:description",
        content: "Manage two-factor authentication and your password.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Security,
});

type Factor = { id: string; status: string; friendly_name?: string | undefined };

function Security() {
  const [factors, setFactors] = useState<Factor[]>([]);
  const [enrolling, setEnrolling] = useState<{ id: string; qr: string; secret: string } | null>(
    null,
  );
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const { data } = await supabase.auth.mfa.listFactors();
    setFactors((data?.totp ?? []) as Factor[]);
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  async function startEnroll() {
    setBusy(true);
    setError(null);
    setNotice(null);
    const { data, error: enrollError } = await supabase.auth.mfa.enroll({
      factorType: "totp",
      friendlyName: `Authenticator ${Date.now()}`,
    });
    setBusy(false);
    if (enrollError) {
      setError(enrollError.message);
      return;
    }
    setEnrolling({ id: data.id, qr: data.totp.qr_code, secret: data.totp.secret });
  }

  async function confirmEnroll(e: React.FormEvent) {
    e.preventDefault();
    if (!enrolling) return;
    setBusy(true);
    setError(null);
    const { data: challenge, error: cErr } = await supabase.auth.mfa.challenge({
      factorId: enrolling.id,
    });
    if (cErr) {
      setBusy(false);
      setError(cErr.message);
      return;
    }
    const { error: vErr } = await supabase.auth.mfa.verify({
      factorId: enrolling.id,
      challengeId: challenge.id,
      code: code.trim(),
    });
    setBusy(false);
    if (vErr) {
      setError(vErr.message);
      return;
    }
    setEnrolling(null);
    setCode("");
    setNotice("Two-factor protection is now active.");
    await refresh();
  }

  async function removeFactor(id: string) {
    setBusy(true);
    setError(null);
    const { error: unErr } = await supabase.auth.mfa.unenroll({ factorId: id });
    setBusy(false);
    if (unErr) {
      setError(unErr.message);
      return;
    }
    setNotice("Two-factor protection removed.");
    await refresh();
  }

  const active = factors.filter((f) => f.status === "verified");

  return (
    <main className="mx-auto max-w-3xl px-6 py-14 lg:px-8">
      <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-steel">Security</p>
      <h1 className="mt-3 font-serif text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
        Two-factor authentication
      </h1>
      <p className="mt-3 max-w-[60ch] text-sm leading-relaxed text-steel">
        Add a one-time code from an authenticator app to every sign-in. It's the single strongest
        protection on your account.
      </p>

      <div className="mt-8 rounded-2xl border border-ink/10 bg-white p-6 shadow-sm">
        {notice ? (
          <p className="mb-5 rounded-[10px] border border-gold/40 bg-gold/10 px-3.5 py-2.5 text-sm text-gold-3">
            {notice}
          </p>
        ) : null}
        {error ? (
          <div className="mb-5">
            <ErrorNote message={error} />
          </div>
        ) : null}

        {active.length > 0 ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-gold" />
              <p className="text-sm font-medium text-ink">Authenticator app is active</p>
            </div>
            <p className="text-sm text-steel">
              You'll be asked for a 6-digit code each time you sign in.
            </p>
            <button
              onClick={() => removeFactor(active[0]!.id)}
              disabled={busy}
              className="rounded-[10px] border border-ink/15 px-4 py-2.5 text-sm font-medium text-ink transition-colors hover:bg-paper-2 disabled:opacity-60"
            >
              Turn off two-factor
            </button>
          </div>
        ) : enrolling ? (
          <form onSubmit={confirmEnroll} className="space-y-5">
            <p className="text-sm text-steel">
              Scan this code in your authenticator app, then enter the 6-digit code it shows.
            </p>
            <img
              src={enrolling.qr}
              alt="Two-factor setup QR code"
              className="size-44 rounded-xl border border-ink/10 bg-white p-2"
            />
            <p className="font-mono text-xs break-all text-steel">
              Manual key: {enrolling.secret}
            </p>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              inputMode="numeric"
              maxLength={6}
              placeholder="000000"
              className="w-full max-w-[14rem] rounded-[10px] border border-ink/15 bg-paper-2 px-3.5 py-2.5 text-center font-mono text-lg tracking-[0.4em] text-ink outline-none focus:border-gold"
              required
            />
            <div className="flex flex-wrap gap-3">
              <button
                type="submit"
                disabled={busy}
                className="rounded-[10px] bg-ink px-5 py-2.5 text-sm font-semibold text-paper transition-transform hover:-translate-y-px disabled:opacity-60"
              >
                {busy ? "Verifying…" : "Confirm and activate"}
              </button>
              <button
                type="button"
                onClick={() => setEnrolling(null)}
                className="rounded-[10px] border border-ink/15 px-5 py-2.5 text-sm text-ink hover:bg-paper-2"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-steel">
              Two-factor protection is currently off for this account.
            </p>
            <button
              onClick={startEnroll}
              disabled={busy}
              className="rounded-[10px] bg-gold px-5 py-2.5 text-sm font-semibold text-ink-2 ring-1 ring-gold/40 transition-transform hover:-translate-y-px disabled:opacity-60"
            >
              {busy ? "Preparing…" : "Set up authenticator app"}
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
