import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import {
  accountsQuery,
  longDate,
  money,
  titleCase,
  transactionsQuery,
  type Transaction,
} from "@/lib/banking";
import {
  EmptyState,
  Loading,
  Panel,
  PageHeader,
  StatusBadge,
  fieldClass,
  ghostButtonClass,
  labelClass,
} from "@/components/banking/ui";
import { TransactionRow } from "@/components/banking/TransactionRow";

export const Route = createFileRoute("/_authenticated/transactions")({
  head: () => ({
    meta: [
      { title: "Transaction history — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "Search and filter every payment, transfer, and deposit on your Trust Worthy Banking Hub accounts.",
      },
      { property: "og:title", content: "Transaction history — Trust Worthy Banking Hub" },
      { property: "og:description", content: "Search and filter your Trust Worthy Banking Hub account activity." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: History,
});

function History() {
  const transactions = useQuery(transactionsQuery());
  const accounts = useQuery(accountsQuery);
  const [search, setSearch] = useState("");
  const [type, setType] = useState("all");
  const [status, setStatus] = useState("all");
  const [category, setCategory] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [selected, setSelected] = useState<Transaction | null>(null);

  const all = transactions.data ?? [];
  const categories = useMemo(
    () => Array.from(new Set(all.map((tx) => tx.category))).sort(),
    [all],
  );

  const filtered = all.filter((tx) => {
    const term = search.trim().toLowerCase();
    if (term && !`${tx.description} ${tx.merchant ?? ""} ${tx.reference}`.toLowerCase().includes(term))
      return false;
    if (type !== "all" && tx.direction !== type) return false;
    if (status !== "all" && tx.status !== status) return false;
    if (category !== "all" && tx.category !== category) return false;
    if (from && new Date(tx.occurred_at) < new Date(from)) return false;
    if (to && new Date(tx.occurred_at) > new Date(`${to}T23:59:59`)) return false;
    return true;
  });

  const accountName = (id: string) => accounts.data?.find((a) => a.id === id)?.name ?? "Account";

  function reset() {
    setSearch("");
    setType("all");
    setStatus("all");
    setCategory("all");
    setFrom("");
    setTo("");
  }

  return (
    <main className="mx-auto max-w-6xl px-6 py-10 lg:px-8">
      <PageHeader
        eyebrow="Activity"
        title="Transaction history"
        subtitle="Everything that has moved through your accounts."
      />

      <Panel className="mt-8">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div className="lg:col-span-3">
            <label className={labelClass} htmlFor="search">
              Search
            </label>
            <input
              id="search"
              className={fieldClass}
              placeholder="Merchant, description, or reference"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div>
            <label className={labelClass} htmlFor="type">
              Type
            </label>
            <select
              id="type"
              className={fieldClass}
              value={type}
              onChange={(e) => setType(e.target.value)}
            >
              <option value="all">All</option>
              <option value="in">Money in</option>
              <option value="out">Money out</option>
            </select>
          </div>
          <div>
            <label className={labelClass} htmlFor="status">
              Status
            </label>
            <select
              id="status"
              className={fieldClass}
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="all">All</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
          </div>
          <div>
            <label className={labelClass} htmlFor="category">
              Category
            </label>
            <select
              id="category"
              className={fieldClass}
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="all">All</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {titleCase(c)}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className={labelClass} htmlFor="fromDate">
              From
            </label>
            <input
              id="fromDate"
              type="date"
              className={fieldClass}
              value={from}
              onChange={(e) => setFrom(e.target.value)}
            />
          </div>
          <div>
            <label className={labelClass} htmlFor="toDate">
              To
            </label>
            <input
              id="toDate"
              type="date"
              className={fieldClass}
              value={to}
              onChange={(e) => setTo(e.target.value)}
            />
          </div>
          <div className="flex items-end">
            <button type="button" className={ghostButtonClass} onClick={reset}>
              Clear filters
            </button>
          </div>
        </div>
      </Panel>

      <Panel className="mt-6">
        <p className="text-sm text-steel">
          {filtered.length} of {all.length} transactions
        </p>
        <div className="mt-2 divide-y divide-ink/5">
          {transactions.isLoading ? (
            <Loading />
          ) : filtered.length === 0 ? (
            <EmptyState title="Nothing matches those filters" hint="Try widening the date range." />
          ) : (
            filtered.map((tx) => <TransactionRow key={tx.id} tx={tx} onSelect={setSelected} />)
          )}
        </div>
      </Panel>

      {selected ? (
        <div
          className="fixed inset-0 z-50 grid place-items-end bg-ink/50 p-0 sm:place-items-center sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-label="Transaction detail"
          onClick={() => setSelected(null)}
        >
          <div
            className="w-full max-w-lg rounded-t-2xl bg-white p-6 shadow-xl sm:rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-steel">
                  {selected.direction === "in" ? "Money in" : "Money out"}
                </p>
                <p className="mt-2 font-serif text-3xl font-semibold text-ink">
                  {money(selected.amount)}
                </p>
              </div>
              <StatusBadge status={selected.status} />
            </div>
            <div className="chrome-line my-5" />
            <dl className="divide-y divide-ink/5 text-sm">
              {[
                ["Description", selected.description],
                ["Merchant", selected.merchant ?? "—"],
                ["Category", titleCase(selected.category)],
                ["Account", accountName(selected.account_id)],
                ["Reference", selected.reference],
                ["Date", longDate(selected.occurred_at)],
              ].map(([term, detail]) => (
                <div key={term} className="flex justify-between gap-6 py-3">
                  <dt className="text-steel">{term}</dt>
                  <dd className="text-right font-medium text-ink">{detail}</dd>
                </div>
              ))}
            </dl>
            <button type="button" className={`${ghostButtonClass} mt-5`} onClick={() => setSelected(null)}>
              Close
            </button>
          </div>
        </div>
      ) : null}
    </main>
  );
}
