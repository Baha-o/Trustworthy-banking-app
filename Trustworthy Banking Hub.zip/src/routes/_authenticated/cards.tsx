import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { TablesUpdate } from "@/integrations/supabase/types";
import { accountsQuery, cardsQuery, errorMessage, money, transactionsQuery } from "@/lib/banking";
import {
  EmptyState,
  Loading,
  Note,
  Panel,
  PageHeader,
  fieldClass,
  ghostButtonClass,
  labelClass,
  primaryButtonClass,
} from "@/components/banking/ui";

export const Route = createFileRoute("/_authenticated/cards")({
  head: () => ({
    meta: [
      { title: "Your cards — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "Reveal card details, freeze your card, set spending limits, and change your PIN.",
      },
      { property: "og:title", content: "Your cards — Trust Worthy Banking Hub" },
      { property: "og:description", content: "Freeze, limit, and manage your Trust Worthy Banking Hub card." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Cards,
});

function Cards() {
  const qc = useQueryClient();
  const cards = useQuery(cardsQuery);
  const accounts = useQuery(accountsQuery);
  const transactions = useQuery(transactionsQuery(200));

  const [revealed, setRevealed] = useState(false);
  const [limit, setLimit] = useState<number | null>(null);
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const card = cards.data?.[0];

  useEffect(() => {
    if (!revealed) return;
    const timer = setTimeout(() => setRevealed(false), 20000);
    return () => clearTimeout(timer);
  }, [revealed]);

  const update = useMutation({
    mutationFn: async (patch: TablesUpdate<"cards">) => {
      const { error: updateError } = await supabase
        .from("cards")
        .update(patch)
        .eq("id", card!.id);
      if (updateError) throw updateError;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["cards"] }),
    onError: (err) => setError(errorMessage(err)),
  });

  if (cards.isLoading) return <Loading label="Loading your card…" />;
  if (!card)
    return (
      <main className="mx-auto max-w-6xl px-6 py-10 lg:px-8">
        <EmptyState title="No cards on this account yet" />
      </main>
    );

  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  const spent = (transactions.data ?? [])
    .filter(
      (tx) =>
        tx.direction === "out" &&
        tx.status === "completed" &&
        new Date(tx.occurred_at) >= monthStart,
    )
    .reduce((sum, tx) => sum + Number(tx.amount), 0);
  const currentLimit = limit ?? Number(card.spending_limit);
  const usage = Math.min(100, Math.round((spent / Math.max(currentLimit, 1)) * 100));
  const linked = accounts.data?.find((a) => a.id === card.account_id);

  return (
    <main className="mx-auto max-w-6xl px-6 py-10 lg:px-8">
      <PageHeader
        eyebrow="Cards"
        title="Card management"
        subtitle="Reveal details, freeze instantly, and control how much can be spent."
      />

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div className="space-y-4">
          <div
            className={`card-face relative overflow-hidden rounded-2xl p-7 text-paper shadow-lg transition-all ${
              card.frozen ? "opacity-50 grayscale" : ""
            }`}
          >
            <div className="flex items-start justify-between">
              <span className="font-serif text-lg font-semibold">
                Trust Worthy<span className="text-gold">.</span>
              </span>
              <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-paper/50">
                {card.brand}
              </span>
            </div>
            <div className="chip-shine mt-8 h-8 w-11 rounded-[6px]" />
            <p className="mt-6 font-mono text-lg tracking-[0.18em]">
              {revealed ? card.number_full : card.number_masked}
            </p>
            <div className="mt-6 flex items-end justify-between text-xs">
              <span>
                <span className="block font-mono text-[10px] uppercase tracking-[0.14em] text-paper/40">
                  Holder
                </span>
                <span className="mt-1 block">{card.holder_name}</span>
              </span>
              <span>
                <span className="block font-mono text-[10px] uppercase tracking-[0.14em] text-paper/40">
                  Expires
                </span>
                <span className="mt-1 block font-mono">{revealed ? card.expiry : "••/••"}</span>
              </span>
              <span>
                <span className="block font-mono text-[10px] uppercase tracking-[0.14em] text-paper/40">
                  CVV
                </span>
                <span className="mt-1 block font-mono">{revealed ? card.cvv : "•••"}</span>
              </span>
            </div>
            {card.frozen ? (
              <span className="absolute right-6 top-1/2 -translate-y-1/2 rounded-full bg-paper px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-ink">
                Frozen
              </span>
            ) : null}
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              className={ghostButtonClass}
              onClick={() => setRevealed((v) => !v)}
            >
              {revealed ? "Hide details" : "Reveal details"}
            </button>
            <button
              type="button"
              className={primaryButtonClass}
              disabled={update.isPending}
              onClick={() => {
                setNotice(card.frozen ? "Card unfrozen." : "Card frozen — payments are blocked.");
                update.mutate({ frozen: !card.frozen });
              }}
            >
              {card.frozen ? "Unfreeze card" : "Freeze card"}
            </button>
          </div>
          <p className="text-xs text-steel">
            Linked to {linked?.name ?? "your account"} · details hide again automatically.
          </p>
        </div>

        <div className="space-y-6">
          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Monthly spending limit</h2>
            <p className="mt-2 font-serif text-3xl font-semibold text-ink">
              {money(currentLimit)}
            </p>
            <input
              type="range"
              min={500}
              max={20000}
              step={500}
              value={currentLimit}
              onChange={(e) => setLimit(Number(e.target.value))}
              className="mt-4 w-full accent-[#c6a15b]"
              aria-label="Monthly spending limit"
            />
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-paper-2">
              <div className="h-full rounded-full bg-gold" style={{ width: `${usage}%` }} />
            </div>
            <p className="mt-2 text-sm text-steel">
              {money(spent)} spent this month · {usage}% of limit
            </p>
            <button
              type="button"
              className={`${primaryButtonClass} mt-4`}
              disabled={update.isPending || currentLimit === Number(card.spending_limit)}
              onClick={() => {
                setNotice(`Spending limit set to ${money(currentLimit)}.`);
                update.mutate({ spending_limit: currentLimit });
              }}
            >
              Save limit
            </button>
          </Panel>

          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Security</h2>
            <div className="mt-4 space-y-4">
              {(
                [
                  ["Contactless payments", "contactless", card.contactless],
                  ["Online payments", "online_payments", card.online_payments],
                ] as const
              ).map(([label, key, value]) => (
                <div key={key} className="flex items-center justify-between gap-4">
                  <span className="text-sm text-ink">{label}</span>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={value}
                    aria-label={label}
                    onClick={() => update.mutate({ [key]: !value })}
                    className={`h-6 w-11 rounded-full transition-colors ${value ? "bg-ink" : "bg-ink/20"}`}
                  >
                    <span
                      className={`block size-5 rounded-full bg-paper transition-transform ${
                        value ? "translate-x-5" : "translate-x-0.5"
                      }`}
                    />
                  </button>
                </div>
              ))}

              <div>
                <label className={labelClass} htmlFor="pin">
                  Change PIN
                </label>
                <div className="flex gap-3">
                  <input
                    id="pin"
                    inputMode="numeric"
                    maxLength={4}
                    className={`${fieldClass} font-mono`}
                    placeholder="••••"
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                  />
                  <button
                    type="button"
                    className={ghostButtonClass}
                    disabled={pin.length !== 4 || update.isPending}
                    onClick={() => {
                      setNotice("PIN updated.");
                      update.mutate({ pin });
                      setPin("");
                    }}
                  >
                    Save
                  </button>
                </div>
              </div>

              {error ? <Note tone="error">{error}</Note> : null}
              {notice ? <Note tone="success">{notice}</Note> : null}
            </div>
          </Panel>
        </div>
      </div>
    </main>
  );
}
