import { createFileRoute, Link, Outlet, redirect, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AegisMark } from "@/components/auth/AuthShell";
import { BottomNav } from "@/components/banking/BottomNav";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth", search: { mode: "signin" } });
    return { user: data.user };
  },
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    await navigate({ to: "/auth", search: { mode: "signin" }, replace: true });
  }

  return (
    <div className="min-h-screen bg-paper pb-20 font-sans text-ink antialiased md:pb-0">
      <header className="bg-ink-2 text-paper">
        <div className="mx-auto max-w-6xl px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-between gap-4 py-5">
            <Link to="/dashboard">
              <AegisMark />
            </Link>
            <nav className="order-3 hidden w-full flex-wrap items-center gap-6 text-sm text-paper/70 md:order-none md:flex md:w-auto">
              {(
                [
                  ["/dashboard", "Overview"],
                  ["/transfers", "Transfers"],
                  ["/transactions", "Activity"],
                  ["/payments", "Payments"],
                  ["/cards", "Cards"],
                  ["/profile", "Profile"],
                  ["/security", "Security"],
                ] as const
              ).map(([to, label]) => (
                <Link
                  key={to}
                  to={to}
                  className="hover:text-paper [&.active]:text-gold-2"
                  activeProps={{ className: "active" }}
                >
                  {label}
                </Link>
              ))}
            </nav>
            <div className="flex items-center gap-3">
              <span className="hidden max-w-[18ch] truncate text-xs text-paper/50 sm:block">
                {user?.email}
              </span>
              <button
                onClick={signOut}
                className="rounded-[10px] border border-paper/20 px-3.5 py-2 text-sm text-paper transition-colors hover:bg-paper/5"
              >
                Sign out
              </button>
            </div>
          </div>
          <div className="chrome-line" />
        </div>
      </header>
      <Outlet />
      <BottomNav />
    </div>
  );
}
