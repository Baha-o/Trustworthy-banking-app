import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  accountsQuery,
  billPaymentsQuery,
  billersQuery,
  errorMessage,
  initials,
  money,
  titleCase,
} from "@/lib/banking";
import {
  EmptyState,
  Note,
  Panel,
  PageHeader,
  StatusBadge,
  fieldClass,
  ghostButtonClass,
  labelClass,
  primaryButtonClass,
} from "@/components/banking/ui";

export const Route = createFileRoute("/_authenticated/payments")({
  head: () => ({
    meta: [
      { title: "Bill payments — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "Pay your billers, schedule recurring payments, and add new utility accounts.",
      },
      { property: "og:title", content: "Bill payments — Trust Worthy Banking Hub" },
      { property: "og:description", content: "Pay billers and schedule recurring payments." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Payments,
});

function Payments() {
  const qc = useQueryClient();
  const billers = useQuery(billersQuery);
  const accounts = useQuery(accountsQuery);
  const payments = useQuery(billPaymentsQuery);

  const [billerId, setBillerId] = useState("");
  const [accountId, setAccountId] = useState("");
  const [amount, setAmount] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [recurrence, setRecurrence] = useState("once");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [newBiller, setNewBiller] = useState("");
  const [newCategory, setNewCategory] = useState("utilities");
  const [newReference, setNewReference] = useState("");

  const accountList = accounts.data ?? [];
  const selectedAccount = accountList.find((a) => a.id === accountId) ?? accountList[0];
  const selectedBiller = billers.data?.find((b) => b.id === billerId);

  const pay = useMutation({
    mutationFn: async () => {
      const { error: rpcError } = await supabase.rpc("pay_bill", {
        _biller_id: billerId,
        _account_id: selectedAccount!.id,
        _amount: Number(amount),
        _recurrence: recurrence,
        ...(dueDate ? { _due_date: dueDate } : {}),
      });
      if (rpcError) throw rpcError;
    },
    onSuccess: () => {
      const scheduled = dueDate && new Date(dueDate) > new Date();
      setNotice(
        scheduled
          ? `Payment to ${selectedBiller?.name} scheduled for ${dueDate}.`
          : `${money(Number(amount))} paid to ${selectedBiller?.name}.`,
      );
      setAmount("");
      setDueDate("");
      setRecurrence("once");
      void qc.invalidateQueries({ queryKey: ["bill_payments"] });
      void qc.invalidateQueries({ queryKey: ["accounts"] });
      void qc.invalidateQueries({ queryKey: ["transactions"] });
    },
    onError: (err) => setError(errorMessage(err)),
  });

  const addBiller = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      const { error: insertError } = await supabase.from("billers").insert({
        user_id: userData.user!.id,
        name: newBiller,
        category: newCategory,
        account_reference: newReference || null,
      });
      if (insertError) throw insertError;
    },
    onSuccess: () => {
      setNewBiller("");
      setNewReference("");
      void qc.invalidateQueries({ queryKey: ["billers"] });
    },
    onError: (err) => setError(errorMessage(err)),
  });

  function submit() {
    setError(null);
    setNotice(null);
    if (!billerId) return setError("Choose a biller.");
    if (!selectedAccount) return setError("Choose an account to pay from.");
    if (!Number(amount)) return setError("Enter an amount greater than zero.");
    pay.mutate();
  }

  const all = payments.data ?? [];
  const upcoming = all.filter((p) => p.status === "scheduled");
  const past = all.filter((p) => p.status !== "scheduled");
  const billerName = (id: string) => billers.data?.find((b) => b.id === id)?.name ?? "Biller";

  return (
    <main className="mx-auto max-w-6xl px-6 py-10 lg:px-8">
      <PageHeader
        eyebrow="Bills"
        title="Payments"
        subtitle="Pay a saved biller, set it to repeat, or add a new one."
      />

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <Panel>
          <h2 className="font-serif text-lg font-semibold text-ink">Pay a biller</h2>

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {(billers.data ?? []).map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => setBillerId(b.id)}
                className={`flex items-center gap-3 rounded-xl border p-3 text-left transition-colors ${
                  billerId === b.id
                    ? "border-gold bg-paper-2/70"
                    : "border-ink/10 hover:bg-paper-2/50"
                }`}
              >
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-ink text-xs font-medium text-paper">
                  {initials(b.name)}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium text-ink">{b.name}</span>
                  <span className="block truncate text-xs text-steel">
                    {titleCase(b.category)} · {b.account_reference ?? "—"}
                  </span>
                </span>
              </button>
            ))}
          </div>

          <div className="mt-6 space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className={labelClass} htmlFor="payAccount">
                  Pay from
                </label>
                <select
                  id="payAccount"
                  className={fieldClass}
                  value={selectedAccount?.id ?? ""}
                  onChange={(e) => setAccountId(e.target.value)}
                >
                  {accountList.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name} — {money(a.balance, a.currency)}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className={labelClass} htmlFor="payAmount">
                  Amount
                </label>
                <input
                  id="payAmount"
                  inputMode="decimal"
                  className={`${fieldClass} font-mono`}
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="payDate">
                  Date
                </label>
                <input
                  id="payDate"
                  type="date"
                  className={fieldClass}
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                />
                <p className="mt-1.5 text-xs text-steel">Leave empty to pay today.</p>
              </div>
              <div>
                <label className={labelClass} htmlFor="payRepeat">
                  Repeat
                </label>
                <select
                  id="payRepeat"
                  className={fieldClass}
                  value={recurrence}
                  onChange={(e) => setRecurrence(e.target.value)}
                >
                  <option value="once">One time</option>
                  <option value="weekly">Every week</option>
                  <option value="monthly">Every month</option>
                </select>
              </div>
            </div>

            {error ? <Note tone="error">{error}</Note> : null}
            {notice ? <Note tone="success">{notice}</Note> : null}

            <button
              type="button"
              className={primaryButtonClass}
              onClick={submit}
              disabled={pay.isPending}
            >
              {pay.isPending ? "Processing…" : "Confirm payment"}
            </button>
          </div>
        </Panel>

        <div className="space-y-6">
          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Add a biller</h2>
            <div className="mt-4 space-y-3">
              <input
                className={fieldClass}
                placeholder="Biller name"
                value={newBiller}
                onChange={(e) => setNewBiller(e.target.value)}
              />
              <select
                className={fieldClass}
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
              >
                <option value="utilities">Utilities</option>
                <option value="internet">Internet & phone</option>
                <option value="insurance">Insurance</option>
                <option value="subscriptions">Subscriptions</option>
                <option value="other">Other</option>
              </select>
              <input
                className={fieldClass}
                placeholder="Account reference"
                value={newReference}
                onChange={(e) => setNewReference(e.target.value)}
              />
              <button
                type="button"
                className={ghostButtonClass}
                disabled={!newBiller || addBiller.isPending}
                onClick={() => addBiller.mutate()}
              >
                {addBiller.isPending ? "Saving…" : "Save biller"}
              </button>
            </div>
          </Panel>

          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Upcoming</h2>
            {upcoming.length === 0 ? (
              <p className="mt-3 text-sm text-steel">Nothing scheduled.</p>
            ) : (
              <ul className="mt-3 divide-y divide-ink/5 text-sm">
                {upcoming.map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-4 py-3">
                    <span>
                      <span className="block text-ink">{billerName(p.biller_id)}</span>
                      <span className="text-xs text-steel">
                        {p.due_date} · {p.recurrence === "once" ? "one time" : p.recurrence}
                      </span>
                    </span>
                    <span className="flex items-center gap-3">
                      <span className="font-mono text-ink">{money(p.amount)}</span>
                      <StatusBadge status={p.status} />
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel>
            <h2 className="font-serif text-lg font-semibold text-ink">Paid</h2>
            {past.length === 0 ? (
              <EmptyState title="No payments yet" />
            ) : (
              <ul className="mt-3 divide-y divide-ink/5 text-sm">
                {past.slice(0, 8).map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-4 py-3">
                    <span>
                      <span className="block text-ink">{billerName(p.biller_id)}</span>
                      <span className="text-xs text-steel">{p.due_date}</span>
                    </span>
                    <span className="flex items-center gap-3">
                      <span className="font-mono text-ink">{money(p.amount)}</span>
                      <StatusBadge status={p.status} />
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>
      </div>
    </main>
  );
}
