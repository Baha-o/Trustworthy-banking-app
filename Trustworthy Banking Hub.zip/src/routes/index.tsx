import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Trust Worthy Banking Hub — Private Digital Banking" },
      {
        name: "description",
        content:
          "Trust Worthy Banking Hub composes checking, savings, and custody into one quiet interface — engineered for people who prefer precision to noise.",
      },
      { property: "og:title", content: "Trust Worthy Banking Hub — Private Digital Banking" },
      {
        property: "og:description",
        content:
          "Banking that holds its weight like a vault door. Checking, savings, and custody in one quiet interface.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-paper font-sans text-ink antialiased">
      {/* NAV */}
      <header className="w-full bg-ink-2 text-paper">
        <div className="mx-auto max-w-6xl px-6 lg:px-8">
          <div className="flex items-center justify-between py-5">
            <a href="#" className="flex items-center gap-2.5">
              <span className="vault-ring grid size-8 place-items-center rounded-[6px] ring-1 ring-black/20">
                <span className="size-3.5 rounded-[3px] bg-ink-2"></span>
              </span>
              <span className="font-serif text-lg font-semibold tracking-tight">
                Trust Worthy<span className="text-gold">.</span>
              </span>
            </a>
            <nav className="hidden items-center gap-8 text-sm text-paper/70 md:flex">
              <a href="#features" className="hover:text-paper">
                Features
              </a>
              <a href="#security" className="hover:text-paper">
                Security
              </a>
              <a href="#accounts" className="hover:text-paper">
                Accounts
              </a>
              <a href="#voices" className="hover:text-paper">
                Voices
              </a>
            </nav>
            <div className="flex items-center gap-3">
              <Link
                to="/auth"
                search={{ mode: "signin" }}
                className="hidden text-sm text-paper/70 hover:text-paper sm:block"
              >
                Sign in
              </Link>
              <Link
                to="/auth"
                search={{ mode: "signup" }}
                className="rounded-[min(1vw,10px)] bg-paper px-4 py-2 text-sm font-medium text-ink ring-1 ring-black/5 transition-transform hover:-translate-y-px"
              >
                Open account
              </Link>
            </div>
          </div>
          <div className="chrome-line"></div>
        </div>
      </header>

      {/* HERO */}
      <section className="vault-face relative w-full overflow-hidden text-paper">
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            background:
              "radial-gradient(60% 50% at 82% 8%, rgba(198,161,91,0.22) 0%, transparent 70%)",
          }}
        ></div>
        <div className="relative mx-auto max-w-6xl px-6 lg:px-8">
          <div className="grid grid-cols-1 items-center gap-12 py-20 lg:grid-cols-12 lg:py-28">
            {/* left */}
            <div className="fade-up lg:col-span-6">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-gold/25 bg-gold/10 px-3 py-1">
                <span className="size-1.5 rounded-full bg-gold-2"></span>
                <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-gold-2">
                  Private digital banking
                </span>
              </div>
              <h1 className="font-serif text-4xl font-semibold leading-tight tracking-tight text-paper text-balance sm:text-5xl lg:text-[3.4rem] max-w-[40ch]">
                Banking that holds its{" "}
                <span className="chrome-text">weight</span> like a vault door.
              </h1>
              <p className="mt-6 max-w-[52ch] text-base leading-relaxed text-paper/70 text-pretty sm:text-lg">
                Trust Worthy Banking Hub composes checking, savings, and custody
                into one quiet interface — engineered for people who prefer
                precision to noise.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-3">
                <Link
                  to="/auth"
                  search={{ mode: "signup" }}
                  className="inline-flex items-center rounded-[min(1vw,10px)] bg-gold px-5 py-3 text-sm font-semibold text-ink-2 ring-1 ring-gold/40 transition-transform hover:-translate-y-px"
                >
                  Open an account
                  <span className="ml-2 inline-block text-ink-2/70">→</span>
                </Link>
                <a
                  href="#security"
                  className="inline-flex items-center rounded-[min(1vw,10px)] border border-paper/20 px-5 py-3 text-sm font-medium text-paper transition-transform hover:bg-paper/5"
                >
                  See how it's secured
                </a>
              </div>
              <div className="mt-10 flex items-center gap-6 border-t border-paper/10 pt-6">
                <div className="flex-1">
                  <div className="font-serif text-2xl font-semibold text-gold-2">
                    $2.4B
                  </div>
                  <div className="mt-1 text-xs uppercase tracking-[0.14em] text-paper/50">
                    Assets held
                  </div>
                </div>
                <div className="h-10 w-px bg-paper/10"></div>
                <div className="flex-1">
                  <div className="font-serif text-2xl font-semibold text-gold-2">
                    0.9ms
                  </div>
                  <div className="mt-1 text-xs uppercase tracking-[0.14em] text-paper/50">
                    Median settle
                  </div>
                </div>
                <div className="hidden h-10 w-px bg-paper/10 sm:block"></div>
                <div className="hidden flex-1 sm:block">
                  <div className="font-serif text-2xl font-semibold text-gold-2">
                    256-bit
                  </div>
                  <div className="mt-1 text-xs uppercase tracking-[0.14em] text-paper/50">
                    At rest
                  </div>
                </div>
              </div>
            </div>

            {/* right: floating product card */}
            <div className="lg:col-span-6">
              <div
                className="fade-up relative mx-auto max-w-md lg:ml-auto"
                style={{ animationDelay: "140ms" }}
              >
                {/* soft glow */}
                <div className="pointer-events-none absolute -inset-6 rounded-[28px] bg-gold/10 blur-2xl"></div>
                {/* the vault dial behind */}
                <div className="vault-ring pointer-events-none absolute -right-10 -top-10 size-40 rounded-full opacity-70"></div>
                <div className="pointer-events-none absolute -right-10 -top-10 grid size-40 place-items-center rounded-full">
                  <span className="size-24 rounded-full bg-ink-2 ring-1 ring-black/30"></span>
                </div>

                {/* main card */}
                <div className="card-face lift relative rounded-[min(1vw,16px)] p-6 outline-1 -outline-offset-1 outline-gold/20 ring-1 ring-black/20">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-paper/40">
                        Trust Worthy · Reserve
                      </div>
                      <div className="mt-3 font-serif text-3xl font-semibold tracking-tight text-paper">
                        $148,204.90
                      </div>
                      <div className="mt-1 font-mono text-xs text-gold-2">
                        +2.4% this quarter
                      </div>
                    </div>
                    <div className="chip-shine grid size-10 place-items-center rounded-[8px] ring-1 ring-black/20">
                      <span className="size-4 rounded-[4px] bg-ink-2/70"></span>
                    </div>
                  </div>
                  <div className="chrome-line my-5 opacity-70"></div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="rounded-[min(1vw,8px)] bg-ink-2/60 p-3 ring-1 ring-white/5">
                      <div className="text-[10px] uppercase tracking-[0.12em] text-paper/40">
                        Cash
                      </div>
                      <div className="mt-1 font-mono text-sm text-paper">
                        $61.2k
                      </div>
                    </div>
                    <div className="rounded-[min(1vw,8px)] bg-ink-2/60 p-3 ring-1 ring-white/5">
                      <div className="text-[10px] uppercase tracking-[0.12em] text-paper/40">
                        Yield
                      </div>
                      <div className="mt-1 font-mono text-sm text-paper">
                        $74.1k
                      </div>
                    </div>
                    <div className="rounded-[min(1vw,8px)] bg-ink-2/60 p-3 ring-1 ring-white/5">
                      <div className="text-[10px] uppercase tracking-[0.12em] text-paper/40">
                        Locked
                      </div>
                      <div className="mt-1 font-mono text-sm text-paper">
                        $12.9k
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center justify-between rounded-[min(1vw,8px)] bg-ink-2/60 p-3 ring-1 ring-white/5">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.12em] text-paper/40">
                        Last transfer
                      </div>
                      <div className="mt-0.5 font-mono text-xs text-paper/80">
                        To Meridian Trust
                      </div>
                    </div>
                    <span className="font-mono text-xs text-gold-2">Settled</span>
                  </div>
                </div>

                {/* floating chip card */}
                <div className="lift absolute -bottom-8 -left-6 w-48 rounded-[min(1vw,12px)] bg-paper p-4 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.5)] ring-1 ring-black/5">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-steel">
                      Trust Worthy Card
                    </span>
                    <span className="chip-shine size-3 rounded-[3px]"></span>
                  </div>
                  <div className="mt-3 font-mono text-sm tracking-wider text-ink">
                    5214 •••• 9077
                  </div>
                  <div className="mt-1 text-[10px] text-steel">G. Halloway</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="w-full bg-paper text-ink">
        <div className="mx-auto max-w-6xl px-6 py-20 lg:px-8 lg:py-28">
          <div className="fade-up max-w-[48ch]">
            <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-gold-3">
              Capabilities
            </div>
            <h2 className="mt-4 font-serif text-3xl font-semibold leading-tight tracking-tight text-balance max-w-[40ch] sm:text-4xl">
              Four instruments, one quiet interface.
            </h2>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <FeatureCard letter="C" title="Cards & custody">
              Physical and virtual cards with per-merchant limits and instant
              freeze, all governed from one ledger.
            </FeatureCard>
            <FeatureCard letter="T" title="Transfers">
              Domestic and cross-border movement with same-day settlement and a
              full, exportable audit trail.
            </FeatureCard>
            <FeatureCard letter="S" title="Savings">
              Tiered yield on your reserve, with locked tranches and scheduled
              contributions that never nag.
            </FeatureCard>
            <FeatureCard letter="B" title="Budgeting">
              Soft envelopes and forecasts that surface drift early, without
              gamifying your own finances.
            </FeatureCard>
          </div>
        </div>
      </section>

      {/* SECURITY / TRUST BAND */}
      <section id="security" className="w-full bg-ink-2 text-paper">
        <div className="mx-auto max-w-6xl px-6 py-20 lg:px-8 lg:py-28">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
            <div className="fade-up lg:col-span-4">
              <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-gold-2">
                Security
              </div>
              <h2 className="mt-4 font-serif text-3xl font-semibold leading-tight tracking-tight text-balance max-w-[36ch] sm:text-4xl">
                Built like a vault door, not a marketing page.
              </h2>
              <p className="mt-5 max-w-[44ch] text-sm leading-relaxed text-paper/60 text-pretty sm:text-base">
                Every session is sealed end-to-end. Hardware keys, segmented
                custody, and continuous monitoring close the door softly — and
                stay closed.
              </p>
              <div className="mt-8 flex flex-wrap gap-2">
                <span className="rounded-full border border-paper/15 px-3 py-1 font-mono text-[11px] text-paper/60">
                  Segregated custody
                </span>
                <span className="rounded-full border border-paper/15 px-3 py-1 font-mono text-[11px] text-paper/60">
                  Hardware keys
                </span>
                <span className="rounded-full border border-paper/15 px-3 py-1 font-mono text-[11px] text-paper/60">
                  24/7 monitoring
                </span>
              </div>
            </div>
            <div className="lg:col-span-8">
              <div className="grid grid-cols-2 gap-px overflow-hidden rounded-[min(1vw,14px)] bg-paper/10 ring-1 ring-black/20 lg:grid-cols-4">
                <TrustStat value="99.99%" label="Uptime, 12 mo" />
                <TrustStat value="146" label="Fraud blocks / day" />
                <TrustStat value="0" label="Breaches to date" />
                <TrustStat value="SOC 2" label="Type II audited" />
              </div>
              <p className="mt-4 font-mono text-[11px] leading-relaxed text-paper/40">
                Independent audits published annually. Custody held with
                regulated partners, never commingled.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ACCOUNT TIERS */}
      <section id="accounts" className="w-full bg-paper text-ink">
        <div className="mx-auto max-w-6xl px-6 py-20 lg:px-8 lg:py-28">
          <div className="fade-up mx-auto max-w-[48ch] text-center">
            <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-gold-3">
              Accounts
            </div>
            <h2 className="mt-4 font-serif text-3xl font-semibold leading-tight tracking-tight text-balance max-w-[38ch] sm:text-4xl">
              Three tiers, one standard of care.
            </h2>
          </div>
          <div className="mt-14 grid grid-cols-1 gap-5 lg:grid-cols-3">
            {/* Personal */}
            <div className="lift flex flex-col rounded-[min(1vw,16px)] bg-paper-2/50 p-7 ring-1 ring-black/5">
              <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-steel">
                Personal
              </div>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="font-serif text-4xl font-semibold tracking-tight">
                  $0
                </span>
                <span className="text-sm text-steel">/ mo</span>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-steel">
                For everyday banking with a first-class card and honest yield.
              </p>
              <ul className="mt-6 space-y-3 text-sm text-ink/80">
                <li className="flex gap-2">
                  <span className="text-gold-3">—</span> Unmetered domestic
                  transfers
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-3">—</span> 2.1% APY on reserve
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-3">—</span> One virtual card
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-3">—</span> Standard support
                </li>
              </ul>
              <a
                href="#"
                className="mt-8 inline-flex justify-center rounded-[min(1vw,10px)] border border-ink/15 px-5 py-3 text-sm font-medium text-ink transition-transform hover:bg-ink/5"
              >
                Start free
              </a>
            </div>

            {/* Reserve (emphasized middle) */}
            <div className="card-face lift relative flex flex-col rounded-[min(1vw,16px)] p-7 text-paper outline-1 -outline-offset-1 outline-gold/20 ring-1 ring-gold/30">
              <span className="chip-shine absolute -top-3 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-2">
                Most chosen
              </span>
              <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-gold-2">
                Reserve
              </div>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="font-serif text-4xl font-semibold tracking-tight">
                  $12
                </span>
                <span className="text-sm text-paper/60">/ mo</span>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-paper/70">
                For those building long. Higher yield, custody, and a dedicated
                desk.
              </p>
              <ul className="mt-6 space-y-3 text-sm text-paper/85">
                <li className="flex gap-2">
                  <span className="text-gold-2">—</span> Everything in Personal
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-2">—</span> 3.4% APY + locked tranches
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-2">—</span> Hardware key & multi-sig
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-2">—</span> Five virtual cards
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-2">—</span> Priority human desk
                </li>
              </ul>
              <a
                href="#"
                className="mt-8 inline-flex justify-center rounded-[min(1vw,10px)] bg-gold px-5 py-3 text-sm font-semibold text-ink-2 ring-1 ring-gold/40 transition-transform hover:-translate-y-px"
              >
                Open Reserve
              </a>
            </div>

            {/* Institutional */}
            <div className="lift flex flex-col rounded-[min(1vw,16px)] bg-paper-2/50 p-7 ring-1 ring-black/5">
              <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-steel">
                Institutional
              </div>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="font-serif text-4xl font-semibold tracking-tight">
                  Custom
                </span>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-steel">
                For funds, firms, and treasuries that need structure and
                reporting.
              </p>
              <ul className="mt-6 space-y-3 text-sm text-ink/80">
                <li className="flex gap-2">
                  <span className="text-gold-3">—</span> Everything in Reserve
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-3">—</span> Segregated custody desks
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-3">—</span> Custom FX & reporting
                </li>
                <li className="flex gap-2">
                  <span className="text-gold-3">—</span> Dedicated relationship
                  lead
                </li>
              </ul>
              <a
                href="#"
                className="mt-8 inline-flex justify-center rounded-[min(1vw,10px)] border border-ink/15 px-5 py-3 text-sm font-medium text-ink transition-transform hover:bg-ink/5"
              >
                Talk to us
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="voices" className="w-full bg-ink text-paper">
        <div className="mx-auto max-w-6xl px-6 py-20 lg:px-8 lg:py-28">
          <div className="fade-up max-w-[48ch]">
            <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-gold-2">
              Voices
            </div>
            <h2 className="mt-4 font-serif text-3xl font-semibold leading-tight tracking-tight text-balance max-w-[40ch] sm:text-4xl">
              Quiet confidence, in their words.
            </h2>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-5 lg:grid-cols-3">
            <Testimonial
              initials="MO"
              name="Mara Okafor"
              role="CFO, Halcyon Labs"
              quote="The reserve account settled a cross-border move before my coffee cooled. It feels less like an app and more like a system."
            />
            <Testimonial
              initials="DT"
              name="Daniel Tran"
              role="Principal, Meridian Trust"
              quote="No neon, no gamification. Just precise limits and a desk that actually picks up. That restraint is exactly why we moved."
            />
            <Testimonial
              initials="PR"
              name="Priya Raman"
              role="Treasurer, Northbank Group"
              quote="The custody reporting dropped into our audits with zero friction. It's the first bank that read like a document, not a dashboard."
            />
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="vault-face w-full text-paper">
        <div className="mx-auto max-w-6xl px-6 py-20 lg:px-8 lg:py-28">
          <div className="card-face fade-up relative overflow-hidden rounded-[min(2vw,24px)] outline-1 -outline-offset-1 outline-gold/20 ring-1 ring-gold/25">
            <div className="vault-ring pointer-events-none absolute -right-16 -top-16 size-56 rounded-full opacity-40"></div>
            <div className="pointer-events-none absolute -right-16 -top-16 grid size-56 place-items-center rounded-full">
              <span className="size-32 rounded-full bg-ink-2 ring-1 ring-black/30"></span>
            </div>
            <div className="relative grid grid-cols-1 gap-8 p-10 lg:grid-cols-12 lg:items-center lg:p-16">
              <div className="lg:col-span-8">
                <h2 className="font-serif text-3xl font-semibold leading-tight tracking-tight text-balance max-w-[44ch] sm:text-[2.6rem]">
                  Close the door on the noise.{" "}
                  <span className="chrome-text">Open Trust Worthy.</span>
                </h2>
                <p className="mt-4 max-w-[50ch] text-base leading-relaxed text-paper/70 text-pretty">
                  Open an account in minutes. No branches, no scripts — just a
                  quiet, precise place for your money.
                </p>
              </div>
              <div className="lg:col-span-4 lg:justify-self-end">
                <Link
                  to="/auth"
                  search={{ mode: "signup" }}
                  className="inline-flex w-full items-center justify-center rounded-[min(1vw,10px)] bg-gold px-6 py-3.5 text-sm font-semibold text-ink-2 ring-1 ring-gold/40 transition-transform hover:-translate-y-px lg:w-auto"
                >
                  Open an account
                  <span className="ml-2 text-ink-2/70">→</span>
                </Link>
                <p className="mt-3 text-center font-mono text-[11px] text-paper/40 lg:text-right">
                  FDIC-eligible · Cancel anytime
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="w-full bg-ink-2 text-paper/60">
        <div className="mx-auto max-w-6xl px-6 py-12 lg:px-8">
          <div className="chrome-line mb-8 opacity-40"></div>
          <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
            <div className="flex items-center gap-2.5">
              <span className="vault-ring grid size-8 place-items-center rounded-[6px] ring-1 ring-black/20">
                <span className="size-3.5 rounded-[3px] bg-ink-2"></span>
              </span>
              <span className="font-serif text-lg font-semibold tracking-tight text-paper">
                Trust Worthy<span className="text-gold">.</span>
              </span>
            </div>
            <nav className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
              <a href="#features" className="hover:text-paper">
                Features
              </a>
              <a href="#security" className="hover:text-paper">
                Security
              </a>
              <a href="#accounts" className="hover:text-paper">
                Accounts
              </a>
              <a href="#" className="hover:text-paper">
                Privacy
              </a>
              <a href="#" className="hover:text-paper">
                Terms
              </a>
            </nav>
          </div>
          <div className="mt-8 space-y-2 border-t border-paper/10 pt-6 font-mono text-[11px] leading-relaxed text-paper/45">
            <p>
              <span className="text-paper/70">Trust Worthy Banking Hub Ltd.</span>{" "}
              — Electronic Money Institution, authorised and regulated as an
              EMI. Regulated by NCA. EMI Licence No. EU-EMI-LT-186593.
            </p>
            <p>
              Electronic money issued by Trust Worthy Banking Hub Ltd. is held in
              segregated safeguarding accounts. Funds are safeguarded under
              applicable payment services regulations.
            </p>
            <p>© 2026 Trust Worthy Banking Hub Ltd. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({
  letter,
  title,
  children,
}: {
  letter: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="lift rounded-[min(1vw,14px)] bg-paper-2/60 p-6 ring-1 ring-black/5">
      <div className="chip-shine grid size-10 place-items-center rounded-[8px] ring-1 ring-black/10">
        <span className="font-serif text-lg font-semibold text-ink-2">
          {letter}
        </span>
      </div>
      <h3 className="mt-5 font-serif text-lg font-semibold tracking-tight">
        {title}
      </h3>
      <p className="mt-2 text-sm leading-relaxed text-steel">{children}</p>
    </div>
  );
}

function TrustStat({ value, label }: { value: string; label: string }) {
  return (
    <div className="bg-ink-2 p-6">
      <div className="chrome-text font-serif text-3xl font-semibold">{value}</div>
      <div className="mt-2 text-xs uppercase tracking-[0.12em] text-paper/50">
        {label}
      </div>
    </div>
  );
}

function Testimonial({
  initials,
  name,
  role,
  quote,
}: {
  initials: string;
  name: string;
  role: string;
  quote: string;
}) {
  return (
    <figure className="lift flex flex-col rounded-[min(1vw,14px)] bg-ink-3 p-7 ring-1 ring-white/5">
      <blockquote className="font-serif text-lg font-medium leading-relaxed text-paper/90">
        “{quote}”
      </blockquote>
      <figcaption className="mt-6 flex items-center gap-3">
        <span className="chip-shine grid size-10 place-items-center rounded-full font-serif text-sm font-semibold text-ink-2">
          {initials}
        </span>
        <span className="text-sm">
          <span className="block font-medium text-paper">{name}</span>
          <span className="block text-paper/50">{role}</span>
        </span>
      </figcaption>
    </figure>
  );
}
