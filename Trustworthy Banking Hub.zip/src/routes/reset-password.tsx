import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  AuthShell,
  fieldClass,
  labelClass,
  primaryButtonClass,
} from "@/components/auth/AuthShell";
import { ErrorNote } from "./auth";

export const Route = createFileRoute("/reset-password")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Choose a new password — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "Set a new password for your Trust Worthy Banking Hub account.",
      },
      { property: "og:title", content: "Choose a new password — Trust Worthy Banking Hub" },
      {
        property: "og:description",
        content: "Set a new password for your Trust Worthy Banking Hub account.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const hash = window.location.hash;
    const isRecovery = hash.includes("type=recovery");
    void supabase.auth.getSession().then(({ data }) => {
      setReady(isRecovery || Boolean(data.session));
    });
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password !== confirm) {
      setError("Those passwords don't match.");
      return;
    }
    setBusy(true);
    setError(null);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (updateError) {
      setError(updateError.message);
      return;
    }
    setDone(true);
    setTimeout(() => {
      void navigate({ to: "/dashboard", replace: true });
    }, 1200);
  }

  return (
    <AuthShell
      eyebrow="New password"
      title={
        <>
          Set a new <span className="chrome-text">password</span>.
        </>
      }
      subtitle="Choose something long and unique. We check it against known breach lists."
      footer={
        <Link to="/auth" search={{ mode: "signin" }} className="text-gold-2 hover:underline">
          ← Back to sign in
        </Link>
      }
    >
      {done ? (
        <p className="text-sm leading-relaxed text-paper/70">
          Password updated. Taking you to your account…
        </p>
      ) : !ready ? (
        <p className="text-sm leading-relaxed text-paper/70">
          This page needs a valid reset link. Request a new one from{" "}
          <Link to="/forgot-password" className="text-gold-2 hover:underline">
            password recovery
          </Link>
          .
        </p>
      ) : (
        <form onSubmit={onSubmit} className="space-y-5">
          <div>
            <label className={labelClass} htmlFor="password">
              New password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={fieldClass}
              autoComplete="new-password"
              minLength={8}
              required
            />
          </div>
          <div>
            <label className={labelClass} htmlFor="confirm">
              Confirm password
            </label>
            <input
              id="confirm"
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className={fieldClass}
              autoComplete="new-password"
              minLength={8}
              required
            />
          </div>
          {error ? <ErrorNote message={error} /> : null}
          <button type="submit" className={primaryButtonClass} disabled={busy}>
            {busy ? "Updating…" : "Update password"}
          </button>
        </form>
      )}
    </AuthShell>
  );
}
