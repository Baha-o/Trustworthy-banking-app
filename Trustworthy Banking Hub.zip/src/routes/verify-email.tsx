import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell, ghostButtonClass } from "@/components/auth/AuthShell";
import { ErrorNote } from "./auth";

type Search = { email?: string };

export const Route = createFileRoute("/verify-email")({
  validateSearch: (search: Record<string, unknown>): Search =>
    typeof search['email'] === "string" ? { email: search['email'] } : {},
  head: () => ({
    meta: [
      { title: "Confirm your email — Trust Worthy Banking Hub" },
      {
        name: "description",
        content: "Confirm your email address to activate your Trust Worthy Banking Hub account.",
      },
      { property: "og:title", content: "Confirm your email — Trust Worthy Banking Hub" },
      {
        property: "og:description",
        content: "Confirm your email address to activate your Trust Worthy Banking Hub account.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: VerifyEmail,
});

function VerifyEmail() {
  const { email } = Route.useSearch();
  const [busy, setBusy] = useState(false);
  const [resent, setResent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function resend() {
    if (!email) return;
    setBusy(true);
    setError(null);
    const { error: resendError } = await supabase.auth.resend({
      type: "signup",
      email,
      options: { emailRedirectTo: `${window.location.origin}/verify-email` },
    });
    setBusy(false);
    if (resendError) {
      setError(resendError.message);
      return;
    }
    setResent(true);
  }

  return (
    <AuthShell
      eyebrow="Email confirmation"
      title={
        <>
          Confirm your <span className="chrome-text">email</span>.
        </>
      }
      subtitle={
        email ? (
          <>
            We sent a confirmation link to <span className="text-gold-2">{email}</span>. Open it to
            activate your account, then sign in.
          </>
        ) : (
          "We sent you a confirmation link. Open it to activate your account, then sign in."
        )
      }
      footer={
        <Link to="/auth" search={{ mode: "signin" }} className="text-gold-2 hover:underline">
          ← Back to sign in
        </Link>
      }
    >
      <div className="space-y-5">
        <ol className="space-y-3 text-sm text-paper/70">
          <li className="flex gap-3">
            <span className="font-mono text-xs text-gold-2">01</span> Open the email from Trust Worthy Banking Hub.
          </li>
          <li className="flex gap-3">
            <span className="font-mono text-xs text-gold-2">02</span> Tap the confirmation link.
          </li>
          <li className="flex gap-3">
            <span className="font-mono text-xs text-gold-2">03</span> Sign in and set up two-factor
            protection.
          </li>
        </ol>
        {error ? <ErrorNote message={error} /> : null}
        {email ? (
          <button type="button" onClick={resend} className={ghostButtonClass} disabled={busy || resent}>
            {resent ? "Confirmation resent" : busy ? "Sending…" : "Resend confirmation email"}
          </button>
        ) : null}
      </div>
    </AuthShell>
  );
}
